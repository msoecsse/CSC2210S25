#include <stdio.h>
#include "function.h"

void hello() {
    printf("Hello from a function!\n");
}
