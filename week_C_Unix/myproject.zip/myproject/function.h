#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void hello();

#endif
